import { fetcher } from 'services/fetcher';
import useSWR from 'swr';

export const usePokemonDescription = (name: string) => {
  const { data, error } = useSWR(
    `https://pokeapi.co/api/v2/pokemon-species/${name}`,
    fetcher
  );

  if (error) return <>failed to load</>;
  if (!data) return <>loading...</>;

  const { flavor_text: description } = data.flavor_text_entries[0];
  return <>{description}</>;
};
