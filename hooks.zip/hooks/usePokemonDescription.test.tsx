import { renderHook } from '@testing-library/react-hooks';

import { usePokemonDescription } from './usePokemonDescription';

describe('usePokemonDescription', () => {
  test('returns a loading state', async () => {
    // jest.spyOn('swr', 'default');
    const { result } = renderHook(() => usePokemonDescription('ditto'));

    // await waitForNextUpdate();

    expect(result.current).toBe(<>loading...</>);
  });

  test('returns an error state', async () => {
    // jest.spyOn('swr', 'default');
    const { result } = renderHook(() => usePokemonDescription('ditto'));

    // await waitForNextUpdate();

    expect(result.current).toBe(<>failed to load</>);
  });

  test('returns a value', async () => {
    // jest.spyOn('swr', 'default');
    const { result } = renderHook(() => usePokemonDescription('ditto'));

    // await waitForNextUpdate();

    expect(result.current).toBe(<>failed to load</>);
  });
});
